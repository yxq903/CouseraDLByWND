## Logistic Regression with a Neural Network mindset to identify cat photos.

> from http://blog.csdn.net/koala_tree/article/details/78057033 

> Which is after class homework of the deep learning lesson from Coursera by Andrew Wg

### Lesson 1 , Week 2

> Please support the official [website](https://www.deeplearning.ai/)